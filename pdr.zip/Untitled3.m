coo = load('coo.txt');
figure
plot(coo(:,2),coo(:,1))
